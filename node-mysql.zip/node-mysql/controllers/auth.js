const mysql = require("mysql");

const db = mysql.createConnection({
	host: process.env.DATABASE_HOST,
	user: process.env.DATABASE_USER,
	password: process.env.DATABASE_PASSWORD,
	database: process.env.DATABASE
});

exports.register = (req, res) => {
	console.log(req.body);
	const { name, email, password } = req.body;
	db.query('SELECT email FROM users WHERE email = ?', [email], (error, results) => {
			console.log(results);
		if(error){
			console.log(error);
		}
		if(results.length > 0){
			return res.render('register',{
				message: 'Email already in use...'
			});
		} 

		db.query('INSERT INTO USERS set ?', {name: name, email: email, password: password }, (error, results) => {
			if(error){
				console.log(error);
			} else{
				return res.render('register',{
					message: 'User Registered...'
				});
			}
		});
	});
	// res.send("Reg Form Submitted...");
}